# CircuitMVVM

CircuitMVVM is an simple, experimental event dispatching and observation library. It was built to assist in writing EventMVVM-style iOS apps. See this blog post for more: [EventMVVM](https://twocentstudios.com/2015/12/08/an-experimental-ios-architecture-based-on-radical-decoupling).

There is currently no example project and only a few tests.

Warning: I would not use this for anything.

## Usage

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## License

CircuitMVVM is available under the MIT license. See the LICENSE file for more info.

## About

CircuitMVVM was created by [Christopher Trott](http://twitter.com/twocentstudios).
