//
//  AppDelegate.h
//  PullShowAnim
//
//  Created by wang hanqing on 13-10-29.
//  Copyright (c) 2013年 wang hanqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
