//
//  HSCButton.h
//  AAAA
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
/*
其实,
 */

@protocol HSCButtonDelegate <NSObject>

- (void)moveButtonWidthDir:(NSInteger)dir 
                  andSpeed:(float)speed 
             positionIndex:(NSInteger)positionIndex;

- (void)moveButtonWidthDir:(NSInteger)dir 
               andDistance:(float)distance 
             positionIndex:(NSInteger)positionIndex;
@end

#import <UIKit/UIKit.h>

enum
{
    Vertical,
    Horizont,
};

@interface HSCButton : UIButton
{
    CGPoint beginPoint;
    float offsetX;
    float offsetY;
    
    NSInteger moveDir;
}
- (id)initWithFrame:(CGRect)frame andTag:(NSInteger)tag;

@property (nonatomic, assign) id<HSCButtonDelegate>delegate;

@property (nonatomic) NSInteger indexHorizont;
@property (nonatomic) NSInteger indexVertical;

@end








