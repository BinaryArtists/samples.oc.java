//
//  HSCButton.m
//  AAAA
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HSCButton.h"

@interface HSCButton()

@end


@implementation HSCButton

@synthesize delegate;
@synthesize indexHorizont;
@synthesize indexVertical;


- (id)initWithFrame:(CGRect)frame andTag:(NSInteger)tag
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        int imageIndex = arc4random()%5;
        NSString *imageNamed = [NSString stringWithFormat:@"%d.png",imageIndex];
        [self setBackgroundImage:[UIImage imageNamed:imageNamed] forState:UIControlStateNormal];
    }
    return self;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

    UITouch *touch = [touches anyObject];
    
    beginPoint = [touch locationInView:self];
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    CGPoint nowPoint = [touch locationInView:self];
    
    offsetX = nowPoint.x - beginPoint.x;
    offsetY = nowPoint.y - beginPoint.y;

    if (abs(abs(offsetX) - abs(offsetY)) > 20)
    {
        if (abs(offsetX) > abs(offsetY)) 
        {
            moveDir = Horizont;
            [delegate moveButtonWidthDir:Horizont 
                                andSpeed:offsetX/10 
                           positionIndex:indexVertical]; 
        }
        else
        {
            moveDir = Vertical;
            [delegate moveButtonWidthDir:Vertical 
                                andSpeed:offsetY/10 
                           positionIndex:indexHorizont]; 
        }  
    }
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    CGSize size = self.frame.size;

    float distance = 0;

    if (moveDir == Horizont) 
    {
        int nextX = size.width*((int)(self.center.x/size.width));
        
        distance = nextX+size.width/2 - self.center.x;

        [delegate moveButtonWidthDir:Horizont 
                         andDistance:distance 
                       positionIndex:indexVertical];        
    }
    else
    {
        int nextY = size.height*((int)(self.center.y/size.height));
        
        distance = nextY+size.height/2 - self.center.y;
        
        [delegate moveButtonWidthDir:Vertical 
                         andDistance:distance 
                       positionIndex:indexHorizont];

    }        

}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
