//
//  ViewController.m
//  DragButtonDemo
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
/*
参数：
    initWithFrame 设置动画区域的frame即：坐标和大小
    horizontCount 水平方向的个数
    verticalCount 垂直方向的个数
 提醒：设置参数的时候最好使用正矩形，倒不是因为好计算，是因为好看
 */
    GridView *gridView = [[GridView alloc] initWithFrame:CGRectMake(75, 100, 200, 200) 
                                           horizontCount:5 
                                           verticalCount:5];
    [self.view addSubview:gridView];
    
    [gridView release];

}




@end









