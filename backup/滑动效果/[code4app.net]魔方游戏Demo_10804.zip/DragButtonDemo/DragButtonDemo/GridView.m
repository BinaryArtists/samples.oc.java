//
//  GridView.m
//  DragButtonDemo
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GridView.h"

@interface GridView()
- (NSInteger)limitValue:(NSInteger)index atMaxValue:(NSInteger)maxValue;
@end

@implementation GridView

- (id)initWithFrame:(CGRect)frame
      horizontCount:(NSInteger)horizontCount
      verticalCount:(NSInteger)verticalCount
{
    self = [super initWithFrame:frame];
    
    
    if (self) 
    {
        self.clipsToBounds = YES;
        
        horCount = horizontCount;
        verCount = verticalCount;
        
        width    = frame.size.width/horCount;
        height   = frame.size.height/verCount;
        
        for (NSInteger i = 0; i < horizontCount*verticalCount; i ++) 
        {
            int indexHorizont = (i%horizontCount);
            int indexVertical = (i/verticalCount);

            HSCButton *hscButton = [[HSCButton alloc] initWithFrame:CGRectMake(indexHorizont*width,
                                                                               indexVertical*height,
                                                                               width,
                                                                               height) andTag:i];
            hscButton.indexHorizont = indexHorizont;
            hscButton.indexVertical = indexVertical;

//            NSString *title =[NSString stringWithFormat:@"%d-%d",tt.indexHorizont,tt.indexVertical];
//            [tt setTitle:title forState:UIControlStateNormal];  

            hscButton.delegate = self;
            [self addSubview:hscButton];
            [hscButton release];      
        }
        
        for (NSInteger i = 0; i < horizontCount; i ++) 
        {
            HSCButton *left = [[HSCButton alloc] initWithFrame:CGRectMake(-width,i*height,width,height) andTag:i];
            left.delegate      = self;
            left.indexHorizont = -1;
            left.indexVertical = i;

//            NSString *title =[NSString stringWithFormat:@"%d-%d",left.indexHorizont,left.indexVertical];
//            [left setTitle:title forState:UIControlStateNormal];  
            [self addSubview:left];
            [left release];
            
            HSCButton *right = [[HSCButton alloc] initWithFrame:CGRectMake(width*horizontCount,i*height,width,height) andTag:i];
            right.delegate = self;
            right.indexHorizont = horizontCount;
            right.indexVertical = i;
//            [right setTitle:[NSString stringWithFormat:@"%d-%d",right.indexHorizont,right.indexVertical] forState:UIControlStateNormal];  

            [self addSubview:right];
            [right release];            
        }
        
        for (NSInteger i = 0; i < verticalCount; i ++) 
        {
            HSCButton *up = [[HSCButton alloc] initWithFrame:CGRectMake(i*width,-height,width,height) andTag:i];
            up.delegate      = self;
            up.indexHorizont = i;
            up.indexVertical = -1;
            
//            NSString *title =[NSString stringWithFormat:@"%d-%d",up.indexHorizont,up.indexVertical];
//            [up setTitle:title forState:UIControlStateNormal];  
            [self addSubview:up];
            [up release];
            
            HSCButton *down = [[HSCButton alloc] initWithFrame:CGRectMake(i*width,height*verticalCount,width,height) andTag:i];
            down.delegate = self;
            down.indexHorizont = i;
            down.indexVertical = verticalCount;
//            [right setTitle:[NSString stringWithFormat:@"%d-%d",right.indexHorizont,right.indexVertical] forState:UIControlStateNormal];  

            [self addSubview:down];
            [down release];            
        }
    }
    return self;
}
#pragma mark -

- (void)moveButtonWidthDir:(NSInteger)dir 
                  andSpeed:(float)speed 
             positionIndex:(NSInteger)positionIndex
{ 
    for (HSCButton *hscButton in self.subviews) 
    {
        if ([hscButton isKindOfClass:[HSCButton class]]) 
        {
            if (dir == Horizont) 
            {
                if (hscButton.indexVertical == positionIndex) 
                {
                    hscButton.center = CGPointMake(hscButton.center.x + speed, hscButton.center.y); 

                    if (speed > 0 && hscButton.frame.origin.x > self.frame.size.width) 
                    {
                        float newX = hscButton.center.x-(horCount+2)*width;
                        hscButton.center = CGPointMake(newX, hscButton.center.y);                        
                    }
                    
                    if (speed < 0 && hscButton.center.x < -width/2) 
                    {
                        float newX = hscButton.center.x + (horCount + 2)*width;
                        hscButton.center = CGPointMake(newX, hscButton.center.y);
                    }
 
                    int indexHorizont = (hscButton.center.x/hscButton.frame.size.width);

                    if (hscButton.center.x < 0)
                    {
                        indexHorizont = -1;
                    }

                    hscButton.indexHorizont = indexHorizont;
                    
//                    NSString *title =[NSString stringWithFormat:@"%d-%d",hscButton.indexHorizont,hscButton.indexVertical];
//                    [hscButton setTitle:title forState:UIControlStateNormal];                   
                }
            }
            else if(dir == Vertical)
            {
                if (hscButton.indexHorizont == positionIndex) 
                {
                    hscButton.center = CGPointMake(hscButton.center.x, hscButton.center.y + speed); 

                    if (speed > 0 && hscButton.frame.origin.y > self.frame.size.height)
                    {
                        float newY = hscButton.center.y - (verCount+2)*height;
                        hscButton.center = CGPointMake(hscButton.center.x, newY);
                    }
                    
                    if (speed < 0 && hscButton.center.y < -height/2) 
                    {
                        float newY = hscButton.center.y + (verCount + 2)*height;
                        hscButton.center = CGPointMake(hscButton.center.x, newY);
                    }
                    
                    int indexVertical = (int)(hscButton.center.y/hscButton.frame.size.height);
                    
                    if (hscButton.center.y < 0) 
                    {
                        indexVertical = -1;
                    }
                    
                    hscButton.indexVertical = indexVertical;
                }
            }           
        }
    }
}

- (void)moveButtonWidthDir:(NSInteger)dir andDistance:(float)distance positionIndex:(NSInteger)positionIndex
{
    for (HSCButton *hscButton in self.subviews) 
    {
        if ([hscButton isKindOfClass:[HSCButton class]]) 
        {
            if (dir == Horizont) 
            {
                if (hscButton.indexVertical==positionIndex) 
                {
                    [UIView beginAnimations:nil context:nil];
                    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
                    [UIView setAnimationDuration:0.3];
                    hscButton.center = CGPointMake(hscButton.center.x + distance, hscButton.center.y);                    
                    [UIView commitAnimations];
                    
                    int indexHorizont = (hscButton.center.x/hscButton.frame.size.width);
                    
                    if (hscButton.center.x < 0) 
                    {
                        indexHorizont = -1;
                    }
                    
                    hscButton.indexHorizont = indexHorizont;
                }
            }
            else if(dir == Vertical)
            {
                if (hscButton.indexHorizont == positionIndex) 
                {
                    [UIView beginAnimations:nil context:nil];
                    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
                    [UIView setAnimationDuration:0.3];
                    hscButton.center = CGPointMake(hscButton.center.x, hscButton.center.y + distance);                    
                    [UIView commitAnimations];
                    
                    int indexVertical = (int)(hscButton.center.y/hscButton.frame.size.height);
                    
                    if (hscButton.center.y < 0) 
                    {
                        indexVertical = -1;
                    }
                    
                    hscButton.indexVertical = indexVertical;
                }
            }           
        }
    }
}



- (NSInteger)limitValue:(NSInteger)index atMaxValue:(NSInteger)maxValue
{
    if (index < 0) 
    {
        index = maxValue;
    }
    
    if (index > maxValue)
    {
        index = 0;
    }
    
    return index;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
