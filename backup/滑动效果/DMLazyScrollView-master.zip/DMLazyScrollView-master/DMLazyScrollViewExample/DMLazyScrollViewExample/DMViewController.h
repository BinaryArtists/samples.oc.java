//
//  DMViewController.h
//  DMLazyScrollViewExample
//
//  Created by Daniele Margutti (me@danielemargutti.com) on 24/11/12.
//  Copyright (c) 2012 http://www.danielemargutti.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DMViewController : UIViewController

@end
