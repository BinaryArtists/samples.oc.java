//
//  ViewController.h
//  UIListView
//
//  Created by SeeKool on 11/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIListView.h"
#import "UIListViewCell.h"


@interface ViewController : UIViewController <UIListViewDelegate, UIListViewDataSource>

@end
