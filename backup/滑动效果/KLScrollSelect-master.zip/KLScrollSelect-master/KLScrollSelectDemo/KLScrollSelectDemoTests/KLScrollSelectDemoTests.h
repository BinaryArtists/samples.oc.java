//
//  KLScrollSelectDemoTests.h
//  KLScrollSelectDemoTests
//
//  Created by Kieran Lafferty on 2013-04-03.
//  Copyright (c) 2013 KieranLafferty. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface KLScrollSelectDemoTests : SenTestCase

@end
