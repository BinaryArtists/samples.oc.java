//
//  KLScrollSelectDemoTests.m
//  KLScrollSelectDemoTests
//
//  Created by Kieran Lafferty on 2013-04-03.
//  Copyright (c) 2013 KieranLafferty. All rights reserved.
//

#import "KLScrollSelectDemoTests.h"

@implementation KLScrollSelectDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in KLScrollSelectDemoTests");
}

@end
