CTMediator
==========

[iOS应用架构谈 组件化方案](http://casatwy.com/iOS-Modulization.html)
