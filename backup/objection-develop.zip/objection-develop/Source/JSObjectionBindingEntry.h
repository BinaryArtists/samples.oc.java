#import <Foundation/Foundation.h>
#import "JSObjectionEntry.h"

@interface JSObjectionBindingEntry : JSObjectionEntry

- (id)initWithObject:(id)theObject;

@end
