#import <Foundation/Foundation.h>
#import "JSObjectionUtils.h"

@interface JSObjectionRuntimePropertyReflector : NSObject<JSObjectionPropertyReflector>

@end
